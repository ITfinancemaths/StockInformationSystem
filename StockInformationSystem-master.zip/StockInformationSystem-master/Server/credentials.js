
module.exports = {
    cookieSecret: '3140102347',
};