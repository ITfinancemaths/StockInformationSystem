/**
 * Created by cs on 2017/6/14.
 */
var OneSignalClient = require('node-onesignal').default

var client = new OneSignalClient("2dc22888-f0e4-4a30-aa9b-2cf79f1a866c", "ZjgxMjM2MmUtNmYyNC00NjBmLTg5MjQtNWUzMDc0OGFmN2Q4")

module.exports = client
