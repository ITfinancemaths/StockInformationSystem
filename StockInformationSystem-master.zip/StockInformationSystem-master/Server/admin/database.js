var db = {
    backend: {
        host: 'tdsql-219vguff.sh.cdb.myqcloud.com',
        user: 'group4',
        password: 'group4..',
        database: 'stockg4',
        port: 26
    },
    group5: {
        host: 'tdsql-219vguff.sh.cdb.myqcloud.com',
        user: 'group5',
        password: 'group5..',
        database: 'stockg5',
        port: 26
    }
};

module.exports = db;
