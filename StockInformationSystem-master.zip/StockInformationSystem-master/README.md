# Stock Information


股票信息发布模块

The Stock Information Publication module of a stock trading system, the team project of software engineering course.

## 启动服务器

```
cd ./Server
npm install
npm start
```

默认监听地址为 localhost:3000
